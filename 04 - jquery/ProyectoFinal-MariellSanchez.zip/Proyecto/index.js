$("#close").click(function(){
    $(".alert").hide();
});

$("#checkout").click(function(){
    Swal.fire('Has comprado todos lo productos seleccionados')
})

$("#button-1").click(function(){
    $("#text-1").html( "Añadido" );
    $("#button-1").css( "color" , "#9678d3");
    $("#button-1").css( "border" , "none");
})

$("#button-2").click(function(){
    $("#text-2").html( "Añadido" );
    $("#button-2").css( "color" , "#9678d3");
    $("#button-2").css( "border" , "none");
})

$("#button-3").click(function(){
    $("#text-3").html( "Añadido" );
    $("#button-3").css( "color" , "#9678d3");
    $("#button-3").css( "border" , "none");
})

$("#button-4").click(function(){
    $("#text-4").html( "Añadido" );
    $("#button-4").css( "color" , "#9678d3");
    $("#button-4").css( "border" , "none");
})

$("#button-5").click(function(){
    $("#text-5").html( "Añadido" );
    $("#button-5").css( "color" , "#9678d3");
    $("#button-5").css( "border" , "none");
})

$("#button-6").click(function(){
    $("#text-6").html( "Añadido" );
    $("#button-6").css( "color" , "#9678d3");
    $("#button-6").css( "border" , "none");
})