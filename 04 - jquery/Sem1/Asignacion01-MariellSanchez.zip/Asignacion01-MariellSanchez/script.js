$("#div_1").html("<div> <p> Este es un ejemplo de div </p> </div>");
$("#div_2").html("<div> <p> Este es un ejemplo de div </p> </div>");

$(".li").html("<li> Esto es una lista </li>");

$("#a_1").html("<a href='https://youtu.be/xqpeVnqldeM' > Haz click sobre mi </a>");
$("#a_2").html("<a href='https://youtu.be/IZM4oVZV40A' > Haz click sobre mi </a>");

$("#label_1").html("<label for='html'> Soy una etiqueta </label>");
$("#label_2").html("<label for='html'> Soy una etiqueta </label>");

$("#quote_1").html("<blockquote> Soy una cita </blockquote>");
$("#quote_2").html("<blockquote> Soy otra cita </blockquote>");

$(".p").html("<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec bibendum ex nec sapien sodales porttitor. Sed et interdum enim. Aenean porta posuere elit, a varius ligula placerat ac. Curabitur dapibus pretium quam sit amet fringilla. Proin aliquam lectus in libero rutrum volutpat. Duis justo nulla, volutpat id dui nec, dignissim pharetra felis.  </p>");
