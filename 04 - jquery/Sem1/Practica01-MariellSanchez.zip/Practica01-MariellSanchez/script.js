$(".card__info").html("<p> <b>Autor: </b> Vincent van Gogh </p> <p> <b>Movimiento: </b> Postimpresionismo </p>");

$("#image_1").html("<img class='card__img' src='src/almond-blossom.jpg'>");
$("#tittle_1").html('<h2 class="card__tittle"> "Almond Blossom" </h2>');

$("#image_2").html("<img class='card__img' src='src/campo-trigo.jpg'>");
$("#tittle_2").html('<h2 class="card__tittle"> "Campo de trigo con cipreses" </h2>');

$("#image_3").html("<img class='card__img' src='src/el-huerto-blanco.jpg' >");
$("#tittle_3").html('<h2 class="card__tittle"> "El huerto blanco" </h2>');

$("#image_4").html("<img class='card__img' src='src/huerto-olivos.jpg' >");
$("#tittle_4").html('<h2 class="card__tittle"> "Huerto de olivos" </h2>');

$("#image_5").html("<img class='card__img' src='src/irises.jpg' >");
$("#tittle_5").html('<h2 class="card__tittle"> "Irises" </h2>');

$("#image_6").html("<img class='card__img' src='src/jardin-poeta.jpg' >");
$("#tittle_6").html('<h2 class="card__tittle"> "El jardín del poeta" </h2>');

$("#image_7").html("<img class='card__img' src='src/la-cosecha.jpg' >");
$("#tittle_7").html('<h2 class="card__tittle"> "La cosecha" </h2>');

$("#image_8").html("<img class='card__img' src='src/la-siesta.jpg' >");
$("#tittle_8").html('<h2 class="card__tittle"> "La siesta" </h2>');

$("#image_9").html("<img class='card__img' src='src/sena.jpg' >");
$("#tittle_9").html('<h2 class="card__tittle"> "Paseo a lo largo del Sena" </h2>');

$("#image_10").html("<img class='card__img' src='src/bedroom.jpg' >");
$("#tittle_10").html('<h2 class="card__tittle"> "Habitación de Vincent en Arles" </h2>');


$("body").css("font-family", "Arial");
$("p").css("font-size", "14px");
$("img").css("border-radius", "10px");
$("html").css("background-color", "beige");

$(".tittle").css("text-align", "center");
$(".tittle").css("color", "rgb(62, 41, 41)");
$(".card").css("width", "200px");
$(".card").css("margin", "20px");
$(".card__img").css("width", "200px");
$(".card__img").css("height", "auto");
$(".card__info").css("text-align", "center");
$(".card__info").css("font-size", "14px");
$(".card__tittle").css("text-align", "center")
$(".card__tittle").css("font-size", "20px");
